
  use walfi;
  alter table game_character 
  add `y` int DEFAULT NULL, 
  add `x` int DEFAULT NULL,
  add `rotation` int DEFAULT NULL,
  add `size` decimal(10,5) DEFAULT NULL, 
  add `item_idx` bigint DEFAULT NULL
  ;
  alter table game_character add FOREIGN KEY (`item_idx`) REFERENCES `game_item` (`item_idx`) ON DELETE CASCADE ON UPDATE CASCADE;
  