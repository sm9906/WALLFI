-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: walfi
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `exchange_history`
--

DROP TABLE IF EXISTS `exchange_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `exchange_history` (
  `고시번호` bigint NOT NULL AUTO_INCREMENT,
  `고시일자` date DEFAULT NULL,
  `통화코드` varchar(5) DEFAULT NULL,
  `통화명` varchar(45) DEFAULT NULL,
  `전신환매입환율` decimal(10,2) DEFAULT NULL,
  `전신환매도환율` decimal(10,2) DEFAULT NULL,
  `매매기준환율` decimal(10,2) DEFAULT NULL,
  `전일대비` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`고시번호`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange_history`
--

LOCK TABLES `exchange_history` WRITE;
/*!40000 ALTER TABLE `exchange_history` DISABLE KEYS */;
INSERT INTO `exchange_history` VALUES (21,'2023-09-20','AUD','호주 달러',863.45,846.36,854.91,0.41),(22,'2023-09-20','CNH','위안화',183.09,179.46,181.28,-2.81),(23,'2023-09-20','EUR','유로',1428.25,1399.96,1414.11,-2.81),(24,'2023-09-20','JPY','일본 옌',905.14,887.21,896.18,5.87),(25,'2023-09-20','USD','미국 달러',1336.93,1310.46,1323.70,-37.20),(26,'2023-09-21','AUD','호주 달러',865.49,848.36,856.93,-2.02),(27,'2023-09-21','CNH','위안화',183.67,180.04,181.86,-0.58),(28,'2023-09-21','EUR','유로',1430.12,1401.81,1415.97,-1.86),(29,'2023-09-21','JPY','일본 옌',905.41,887.48,896.45,-0.27),(30,'2023-09-21','USD','미국 달러',1342.59,1316.00,1329.30,-5.60),(36,'2023-09-22','AUD','호주 달러',867.62,850.43,859.03,-2.10),(37,'2023-09-22','CNH','위안화',185.18,181.51,183.35,-1.49),(38,'2023-09-22','EUR','유로',1441.88,1413.33,1427.61,-11.64),(39,'2023-09-22','JPY','일본 옌',916.41,898.26,907.34,-10.89),(40,'2023-09-22','USD','미국 달러',1352.49,1325.70,1339.10,-9.80);
/*!40000 ALTER TABLE `exchange_history` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-22 14:35:40
