-- MySQL dump 10.13  Distrib 8.0.34, for Linux (x86_64)
--
-- Host: localhost    Database: walfi
-- ------------------------------------------------------
-- Server version    8.0.34-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `crypto_wallet`
--

DROP TABLE IF EXISTS `crypto_wallet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crypto_wallet` (
  `Id` bigint NOT NULL AUTO_INCREMENT,
  `json_wallet` varchar(800) NOT NULL,
  `encpwd` varchar(200) NOT NULL,
  `password_key` varchar(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `coin_type` varchar(45) NOT NULL,
  `대표계좌` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Fk_idx` (`대표계좌`),
  CONSTRAINT `Fk` FOREIGN KEY (`대표계좌`) REFERENCES `user` (`대표계좌`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crypto_wallet`
--

LOCK TABLES `crypto_wallet` WRITE;
/*!40000 ALTER TABLE `crypto_wallet` DISABLE KEYS */;
INSERT INTO `crypto_wallet` VALUES (1,'{\"address\":\"036f648cff81d850ffef601fe01a3041951d94f3\",\"id\":\"9db90bb4-de00-4596-a203-1f7ab3816f64\",\"version\":3,\"crypto\":{\"cipher\":\"aes-128-ctr\",\"ciphertext\":\"a9ba3a686f0684ade65c72f1137365ddb7fe05cd3bb3ce265335293869ca4423\",\"cipherparams\":{\"iv\":\"b0d18ee181f33ed73c7bae341c03b773\"},\"kdf\":\"scrypt\",\"kdfparams\":{\"dklen\":32,\"n\":262144,\"p\":1,\"r\":8,\"salt\":\"3007bf106d564bb26a3eb6e4ba3037fc827d52b88ce221889d118c7309cd6105\"},\"mac\":\"decccb0640cc522bc550a15ace1e05b165ed4ace9493567d6b9960976733b70c\"}}','qd0Pa99azL5P9fjZAX7jzlBW/k7lWFME5vn4nCIk387lHCNZCP9EmDDQwJBZ8A1D','H31Ko7HGnKKsn0D4xz7Ylg==','0x036f648cff81d850ffef601fe01a3041951d94f3','SEP','123'),(2,'{\"address\":\"ef8b22a538ae8c4dded4fcb88ed61bb260a59503\",\"id\":\"f35f73a1-0fb3-40e2-9760-e334e15cef6c\",\"version\":3,\"crypto\":{\"cipher\":\"aes-128-ctr\",\"ciphertext\":\"6f9e1ccbe39f49950e13a1ab94ac4fbbb550634ef8f12a976f57d7d39a6c15a3\",\"cipherparams\":{\"iv\":\"3ca578b428109fa3534280ab9ec6af13\"},\"kdf\":\"scrypt\",\"kdfparams\":{\"dklen\":32,\"n\":262144,\"p\":1,\"r\":8,\"salt\":\"fa5878aeea4e25cf5640def48279a247db98e39870cf9878fa0d71c0e125bacb\"},\"mac\":\"9957b3763378b25cb8aa997e4d88100af2a8e1182e8ede46a6d6e879bd0319b8\"}}','236GlkP3TNiMEUniReIFL/Diw1bki9nWLppM8fbr9YopFjl5wxLBtz5+U24z3E/D','iOTsDK7FA++n7u9EYOpgWg==','0xef8b22a538ae8c4dded4fcb88ed61bb260a59503','SEP','110001785538');
/*!40000 ALTER TABLE `crypto_wallet` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-04  9:28:29

